/* ============================================================
   CONSTANTS
   ============================================================ */
const POSTS_PER_PAGE = 10;      // сколько постов на одной странице
const AVATAR_PALETTE = ['#7c6ef7','#f7a86e','#56d99c','#6ec8f7','#e87cf7','#f76e8e'];
const MONTHS = ['ЯНВ','ФЕВ','МАР','АПР','МАЙ','ИЮН','ИЮЛ','АВГ','СЕН','ОКТ','НОЯ','ДЕК'];

/* ============================================================
   STATE  (загружается из data.json)
   ============================================================ */
let DATA = null;          // все данные из JSON
let USERS = [];           // зарегистрированные пользователи (in-memory)
let CURRENT_USER = null;  // залогиненный пользователь
let selectedRole = 'student';
let feedPage = 1;         // текущая страница ленты

/* ============================================================
   UTILS — вспомогательные функции
   ============================================================ */

/** Форматирует строку даты "YYYY-MM-DD" → { day, month } */
function formatDate(dateStr) {
  if (!dateStr) return { day: '—', month: '' };
  const [, m, d] = dateStr.split('-');
  return { day: parseInt(d, 10), month: MONTHS[parseInt(m, 10) - 1] };
}

/** Возвращает текущее время как "HH:MM" */
function getCurrentTime() {
  const d = new Date();
  return `${d.getHours()}:${String(d.getMinutes()).padStart(2, '0')}`;
}

/** Генерирует инициалы из имени */
function getInitials(name) {
  return name.trim().split(' ').map(w => w[0]).join('').slice(0, 2).toUpperCase();
}

/** Пагинация: возвращает срез массива и мета-информацию */
function paginate(items, page, perPage) {
  const totalPages = Math.max(1, Math.ceil(items.length / perPage));
  const safePage   = Math.min(Math.max(1, page), totalPages);
  const start      = (safePage - 1) * perPage;
  return {
    items:      items.slice(start, start + perPage),
    page:       safePage,
    totalPages,
    hasPrev:    safePage > 1,
    hasNext:    safePage < totalPages,
  };
}

/* ============================================================
   ЗАГРУЗКА ДАННЫХ из data.json
   ============================================================ */
async function loadData() {
  const res  = await fetch('data.json');
  DATA = await res.json();
  // Делаем глубокую копию, чтобы пользователь мог мутировать данные
  DATA.posts    = DATA.posts.map(p => ({ ...p, comments: [...p.comments] }));
  DATA.groups   = DATA.groups.map(g => ({ ...g }));
  DATA.events   = DATA.events.map(e => ({ ...e }));
  DATA.contacts = DATA.contacts.map(c => ({ ...c, messages: [...c.messages] }));
  DATA.activeContactId = DATA.contacts[0]?.id ?? null;
  init();
}

/* ============================================================
   NAVIGATION
   ============================================================ */
function navigate(tab) {
  document.querySelectorAll('.nav-item').forEach(n =>
    n.classList.toggle('active', n.dataset.tab === tab));
  document.querySelectorAll('.tab').forEach(t =>
    t.classList.toggle('active', t.dataset.tab === tab));
  document.querySelectorAll('.panel').forEach(p =>
    p.classList.toggle('active', p.id === 'panel-' + tab));
}

/* ============================================================
   FEED — лента с пагинацией
   ============================================================ */
function renderFeed() {
  const { items, page, totalPages, hasPrev, hasNext } = paginate(
    DATA.posts, feedPage, POSTS_PER_PAGE
  );
  feedPage = page;

  // Рендерим карточки
  const list = document.getElementById('postList');
  list.innerHTML = '';
  items.forEach(post => list.appendChild(buildPostCard(post)));

  // Рендерим пагинацию
  renderPagination(page, totalPages, hasPrev, hasNext);

  // Обновляем дропдаун групп в composer
  const sel = document.getElementById('postGroup');
  sel.innerHTML = '<option value="">📢 Общее</option>';
  DATA.groups.filter(g => g.joined).forEach(g => {
    const o = document.createElement('option');
    o.value = g.id;
    o.textContent = g.icon + ' ' + g.name;
    sel.appendChild(o);
  });
}

function renderPagination(page, totalPages, hasPrev, hasNext) {
  const container = document.getElementById('feedPagination');
  container.innerHTML = '';
  if (totalPages <= 1) return;

  // Кнопка «назад»
  const prev = document.createElement('button');
  prev.className = 'page-btn arrow';
  prev.textContent = '←';
  prev.disabled = !hasPrev;
  prev.addEventListener('click', () => { feedPage--; renderFeed(); scrollToFeedTop(); });
  container.appendChild(prev);

  // Номера страниц
  for (let i = 1; i <= totalPages; i++) {
    // Показываем: первую, последнюю, текущую и ±1 от неё
    const isNearCurrent = Math.abs(i - page) <= 1;
    const isEdge = i === 1 || i === totalPages;
    if (!isNearCurrent && !isEdge) {
      // Многоточие (только один раз подряд)
      const last = container.lastChild;
      if (last && last.textContent !== '…') {
        const dots = document.createElement('span');
        dots.textContent = '…';
        dots.style.cssText = 'color:var(--muted);padding:0 4px;font-size:13px';
        container.appendChild(dots);
      }
      continue;
    }
    const btn = document.createElement('button');
    btn.className = 'page-btn' + (i === page ? ' active' : '');
    btn.textContent = i;
    btn.addEventListener('click', () => { feedPage = i; renderFeed(); scrollToFeedTop(); });
    container.appendChild(btn);
  }

  // Кнопка «вперёд»
  const next = document.createElement('button');
  next.className = 'page-btn arrow';
  next.textContent = '→';
  next.disabled = !hasNext;
  next.addEventListener('click', () => { feedPage++; renderFeed(); scrollToFeedTop(); });
  container.appendChild(next);
}

function scrollToFeedTop() {
  document.getElementById('panel-feed').scrollTo({ top: 0, behavior: 'smooth' });
}

function buildPostCard(post) {
  const card = document.createElement('div');
  card.className = 'post-card';
  card.id = 'post-' + post.id;

  const groupBadge = post.group
    ? `<span class="post-badge">${post.groupIcon} ${post.group}</span>` : '';

  const commentsHtml = buildCommentsHtml(post.comments);

  card.innerHTML = `
    <div class="post-header">
      <div class="avatar" style="background:${post.color};color:${post.colorText}">${post.initials}</div>
      <div class="post-meta">
        <div class="post-author">${post.author}</div>
        <div class="post-time">${post.time}</div>
      </div>
      ${groupBadge}
    </div>
    <div class="post-text">${post.text}</div>
    <div class="post-actions">
      <button class="action-btn ${post.liked ? 'liked' : ''}" data-action="like" data-id="${post.id}">
        ❤️ <span class="like-count">${post.likes}</span>
      </button>
      <button class="action-btn" data-action="comment" data-id="${post.id}">
        💬 <span class="comment-count">${commentWord(post.comments.length)}</span>
      </button>
      <button class="action-btn" data-action="share">↗️ Поделиться</button>
    </div>
    <div class="comments-section" id="comments-${post.id}">
      <div class="comments-list">${commentsHtml}</div>
      <div class="comment-input-row">
        <input class="comment-input" id="cinput-${post.id}" placeholder="Написать комментарий...">
        <button class="btn btn-ghost btn-sm" data-addcomment="${post.id}">Отправить</button>
      </div>
    </div>`;

  card.querySelector('[data-action="like"]').addEventListener('click', function() { toggleLike(post.id, this); });
  card.querySelector('[data-action="comment"]').addEventListener('click', function() { toggleComments(post.id, this); });
  card.querySelector('[data-action="share"]').addEventListener('click', () => showToast('Ссылка скопирована! 🔗', 'success'));
  card.querySelector(`[data-addcomment="${post.id}"]`).addEventListener('click', () => addComment(post.id));
  card.querySelector(`#cinput-${post.id}`).addEventListener('keydown', e => {
    if (e.key === 'Enter') addComment(post.id);
  });

  return card;
}

function buildCommentsHtml(comments) {
  return comments.map(c => `
    <div class="comment-item">
      <div class="avatar" style="background:var(--surface2);color:var(--muted);width:28px;height:28px;font-size:11px;border-radius:8px">
        ${c.author.split(' ').map(w => w[0]).join('').slice(0, 2)}
      </div>
      <div class="comment-body">
        <div class="comment-author">${c.author}</div>
        <div class="comment-text">${c.text}</div>
      </div>
    </div>`).join('');
}

function commentWord(n) {
  if (n === 1) return '1 ответ';
  if (n >= 2 && n <= 4) return `${n} ответа`;
  return `${n} ответов`;
}

function toggleLike(postId, btn) {
  const post = DATA.posts.find(p => p.id === postId);
  if (!post) return;
  post.liked = !post.liked;
  post.likes += post.liked ? 1 : -1;
  btn.classList.toggle('liked', post.liked);
  btn.querySelector('.like-count').textContent = post.likes;
}

function toggleComments(postId, btn) {
  const section = document.getElementById('comments-' + postId);
  const isOpen  = section.classList.toggle('open');
  const post    = DATA.posts.find(p => p.id === postId);
  if (post) btn.querySelector('.comment-count').textContent = commentWord(post.comments.length);
  if (isOpen) document.getElementById('cinput-' + postId)?.focus();
}

function addComment(postId) {
  const input = document.getElementById('cinput-' + postId);
  const text  = input.value.trim();
  if (!text) return;
  const post = DATA.posts.find(p => p.id === postId);
  if (!post) return;
  post.comments.push({ author: DATA.me.name, text });
  input.value = '';
  // Обновляем только список комментариев, не перерисовываем весь пост
  document.querySelector(`#comments-${postId} .comments-list`).innerHTML = buildCommentsHtml(post.comments);
  document.querySelector(`#post-${postId} .comment-count`).textContent = commentWord(post.comments.length);
  showToast('Комментарий добавлен ✓', 'success');
}

function publishPost() {
  const text = document.getElementById('postText').value.trim();
  if (!text) { showToast('Напишите что-нибудь 😊', 'error'); return; }

  const groupId = document.getElementById('postGroup').value;
  const group   = DATA.groups.find(g => String(g.id) === String(groupId));

  DATA.posts.unshift({
    id: Date.now(),
    author: DATA.me.name, initials: DATA.me.initials,
    color: DATA.me.color, colorText: '#fff',
    group: group ? group.name : '', groupIcon: group ? group.icon : '',
    time: 'только что', text,
    likes: 0, liked: false, comments: [],
  });

  document.getElementById('postText').value = '';
  feedPage = 1;
  renderFeed();
  showToast('Пост опубликован! 🎉', 'success');
}

/* ============================================================
   EVENTS
   ============================================================ */
function renderEvents() {
  const container = document.getElementById('eventsList');
  container.innerHTML = '';

  const sel = document.getElementById('newEventGroup');
  sel.innerHTML = '<option value="Общелицейское">📢 Общелицейское</option>';
  DATA.groups.forEach(g => {
    const o = document.createElement('option');
    o.value = g.name; o.textContent = g.icon + ' ' + g.name;
    sel.appendChild(o);
  });

  DATA.events.forEach(ev => container.appendChild(buildEventCard(ev)));
}

function buildEventCard(ev) {
  const { day, month } = formatDate(ev.date);
  const card = document.createElement('div');
  card.className = `event-card color-${ev.color}`;
  card.id = 'event-' + ev.id;
  card.innerHTML = `
    <div class="event-date-num">${day}</div>
    <div class="event-month-label">${month}${ev.location ? ' · ' + ev.location : ''}</div>
    <div class="event-title">${ev.title}</div>
    <div class="event-desc">${ev.desc}</div>
    <div class="event-footer">
      <span class="event-group-tag">${ev.group}</span>
      <button class="going-btn ${ev.going ? 'going' : ''}" data-evid="${ev.id}">
        ${ev.going ? '✓ Иду' : 'Пойду'}
      </button>
    </div>`;
  card.querySelector(`[data-evid="${ev.id}"]`).addEventListener('click', function() { toggleGoing(ev.id, this); });
  return card;
}

function toggleGoing(evId, btn) {
  const ev = DATA.events.find(e => e.id === evId);
  if (!ev) return;
  ev.going = !ev.going;
  btn.classList.toggle('going', ev.going);
  btn.textContent = ev.going ? '✓ Иду' : 'Пойду';
  showToast(ev.going ? '✓ Ты записан(а)!' : 'Запись отменена', ev.going ? 'success' : '');
}

function createEvent() {
  const title    = document.getElementById('newEventTitle').value.trim();
  const desc     = document.getElementById('newEventDesc').value.trim();
  const date     = document.getElementById('newEventDate').value;
  const location = document.getElementById('newEventLocation').value.trim();
  const group    = document.getElementById('newEventGroup').value;
  if (!title) { showToast('Введите название мероприятия', 'error'); return; }
  const colors = ['a','b','c','d'];
  const ev = { id: Date.now(), title, desc, date, location, group, going: false,
    color: colors[DATA.events.length % colors.length] };
  DATA.events.unshift(ev);
  const container = document.getElementById('eventsList');
  container.insertBefore(buildEventCard(ev), container.firstChild);
  closeModal('eventModal');
  ['newEventTitle','newEventDesc','newEventDate','newEventLocation'].forEach(id => {
    document.getElementById(id).value = '';
  });
  showToast('Мероприятие создано! 📅', 'success');
}

/* ============================================================
   GROUPS
   ============================================================ */
function renderGroups() {
  const container = document.getElementById('groupsList');
  container.innerHTML = '';
  DATA.groups.forEach(g => container.appendChild(buildGroupCard(g)));
  renderMyGroupsSidebar();
}

function buildGroupCard(g) {
  const card = document.createElement('div');
  card.className = 'group-card';
  card.id = 'group-' + g.id;
  card.innerHTML = `
    <div class="group-icon-wrap" style="background:${g.color}">${g.icon}</div>
    <div class="group-name">${g.name}</div>
    <div class="group-desc">${g.desc}</div>
    <div class="group-footer">
      <span class="group-members-count">👥 ${g.members} участн.</span>
      <button class="join-btn ${g.joined ? 'joined' : ''}" data-gid="${g.id}">
        ${g.joined ? 'Вступил' : 'Вступить'}
      </button>
    </div>`;
  card.querySelector(`[data-gid="${g.id}"]`).addEventListener('click', function() { toggleJoin(g.id, this, card); });
  return card;
}

function toggleJoin(groupId, btn, card) {
  const g = DATA.groups.find(x => x.id === groupId);
  if (!g) return;
  g.joined = !g.joined;
  g.members += g.joined ? 1 : -1;
  btn.textContent = g.joined ? 'Вступил' : 'Вступить';
  btn.classList.toggle('joined', g.joined);
  card.querySelector('.group-members-count').textContent = `👥 ${g.members} участн.`;
  renderMyGroupsSidebar();
  renderFeed(); // обновить дропдаун групп
  showToast(g.joined ? `Добро пожаловать в «${g.name}»! 🎉` : `Вы покинули «${g.name}»`, g.joined ? 'success' : '');
}

function renderMyGroupsSidebar() {
  const container = document.getElementById('myGroupsList');
  container.innerHTML = '';
  DATA.groups.filter(g => g.joined).forEach(g => {
    const el = document.createElement('div');
    el.className = 'nav-item';
    el.innerHTML = `<span class="nav-icon">${g.icon}</span> ${g.name}`;
    el.addEventListener('click', () => navigate('groups'));
    container.appendChild(el);
  });
}

function createGroup() {
  const name = document.getElementById('newGroupName').value.trim();
  const desc = document.getElementById('newGroupDesc').value.trim();
  const icon = document.getElementById('newGroupIcon').value.trim() || '💡';
  if (!name) { showToast('Введите название группы', 'error'); return; }
  const colors = ['rgba(124,110,247,0.15)','rgba(247,168,110,0.15)','rgba(86,217,156,0.15)','rgba(110,200,247,0.15)'];
  const g = { id: Date.now(), name, desc, icon, color: colors[DATA.groups.length % colors.length], members: 1, joined: true };
  DATA.groups.unshift(g);
  const container = document.getElementById('groupsList');
  container.insertBefore(buildGroupCard(g), container.firstChild);
  renderMyGroupsSidebar();
  renderFeed();
  closeModal('groupModal');
  ['newGroupName','newGroupDesc','newGroupIcon'].forEach(id => { document.getElementById(id).value = ''; });
  showToast(`Группа «${name}» создана! 🎯`, 'success');
}

/* ============================================================
   MESSAGES
   ============================================================ */
function renderMessages() {
  const list = document.getElementById('msgContactList');
  list.innerHTML = '';
  DATA.contacts.forEach(c => {
    const lastMsg = c.messages[c.messages.length - 1];
    const item = document.createElement('div');
    item.className = 'msg-item' + (c.id === DATA.activeContactId ? ' active' : '');
    item.id = 'contact-' + c.id;
    item.innerHTML = `
      <div class="avatar" style="background:${c.color};color:${c.colorText}">${c.initials}</div>
      <div class="msg-item-info">
        <div class="msg-item-name">${c.name}</div>
        <div class="msg-item-preview">${lastMsg ? (lastMsg.out ? 'Вы: ' : '') + lastMsg.text : '—'}</div>
      </div>
      ${c.unread > 0 ? `<span class="msg-unread">${c.unread}</span>` : ''}`;
    item.addEventListener('click', () => openChat(c.id));
    list.appendChild(item);
  });
  openChat(DATA.activeContactId);
  updateMsgBadge();
}

function openChat(contactId) {
  DATA.activeContactId = contactId;
  const c = DATA.contacts.find(x => x.id === contactId);
  if (!c) return;
  c.unread = 0;
  updateMsgBadge();
  document.querySelectorAll('.msg-item').forEach(el =>
    el.classList.toggle('active', el.id === 'contact-' + contactId));
  document.querySelector(`#contact-${contactId} .msg-unread`)?.remove();
  document.getElementById('chatAvatar').textContent    = c.initials;
  document.getElementById('chatAvatar').style.background = c.color;
  document.getElementById('chatAvatar').style.color   = c.colorText;
  document.getElementById('chatName').textContent     = c.name;
  document.getElementById('chatStatus').textContent   = '● ' + c.status;
  const area = document.getElementById('chatMessages');
  area.innerHTML = '';
  c.messages.forEach(m => area.appendChild(buildBubble(m)));
  area.scrollTop = area.scrollHeight;
}

function buildBubble(m) {
  const wrap = document.createElement('div');
  wrap.className = 'bubble-wrap ' + (m.out ? 'out' : 'inc');
  wrap.innerHTML = `<div class="msg-bubble">${m.text}</div><div class="bubble-time">${m.time}</div>`;
  return wrap;
}

function sendMessage() {
  const input = document.getElementById('chatInput');
  const text  = input.value.trim();
  if (!text) return;
  const c = DATA.contacts.find(x => x.id === DATA.activeContactId);
  if (!c) return;
  const msg = { out: true, text, time: getCurrentTime() };
  c.messages.push(msg);
  const area = document.getElementById('chatMessages');
  area.appendChild(buildBubble(msg));
  area.scrollTop = area.scrollHeight;
  input.value = '';
  const preview = document.querySelector(`#contact-${c.id} .msg-item-preview`);
  if (preview) preview.textContent = 'Вы: ' + text;
}

function updateMsgBadge() {
  const total = DATA.contacts.reduce((s, c) => s + c.unread, 0);
  const badge = document.getElementById('msgBadge');
  badge.textContent  = total;
  badge.style.display = total > 0 ? '' : 'none';
}

/* ============================================================
   MODAL
   ============================================================ */
function openModal(id)  { document.getElementById(id).classList.add('open'); }
function closeModal(id) { document.getElementById(id).classList.remove('open'); }

/* ============================================================
   TOAST
   ============================================================ */
let toastTimer;
function showToast(msg, type = '') {
  const t = document.getElementById('toast');
  t.textContent = msg;
  t.className = 'toast show ' + type;
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => { t.className = 'toast'; }, 3000);
}

/* ============================================================
   AUTH
   ============================================================ */
function selectRole(role) {
  selectedRole = role;
  document.getElementById('roleStudent').classList.toggle('selected', role === 'student');
  document.getElementById('roleTeacher').classList.toggle('selected', role === 'teacher');
  document.getElementById('classField').style.display   = role === 'student' ? '' : 'none';
  document.getElementById('subjectField').style.display = role === 'teacher' ? '' : 'none';
}

function switchAuthTab(tab) {
  document.querySelectorAll('.auth-tab').forEach((t, i) =>
    t.classList.toggle('active', (i === 0) === (tab === 'login')));
  document.getElementById('loginForm').classList.toggle('active', tab === 'login');
  document.getElementById('registerForm').classList.toggle('active', tab === 'register');
}

function showAuthError(id, msg) {
  const el = document.getElementById(id);
  el.textContent = msg;
  el.classList.add('show');
  setTimeout(() => el.classList.remove('show'), 4000);
}

function doLogin() {
  const email    = document.getElementById('loginEmail').value.trim().toLowerCase();
  const password = document.getElementById('loginPassword').value;
  if (!email || !password) { showAuthError('loginError', 'Заполните все поля'); return; }
  const user = USERS.find(u => u.email === email && u.password === password);
  if (!user) { showAuthError('loginError', 'Неверный email или пароль'); return; }
  loginUser(user);
}

function doRegister() {
  const name     = document.getElementById('regName').value.trim();
  const email    = document.getElementById('regEmail').value.trim().toLowerCase();
  const password = document.getElementById('regPassword').value;
  if (!name || !email || !password) { showAuthError('regError', 'Заполните все поля'); return; }
  if (password.length < 6)          { showAuthError('regError', 'Пароль минимум 6 символов'); return; }
  if (!email.includes('@'))         { showAuthError('regError', 'Введите корректный email'); return; }
  if (USERS.find(u => u.email === email)) { showAuthError('regError', 'Этот email уже зарегистрирован'); return; }

  const initials = getInitials(name);
  const color    = AVATAR_PALETTE[USERS.length % AVATAR_PALETTE.length];
  const user     = { id: Date.now(), name, email, password, role: selectedRole, initials, color };

  if (selectedRole === 'student') {
    const num    = document.getElementById('regClassNum').value.trim();
    const letter = document.getElementById('regClassLetter').value.trim().toUpperCase();
    user.classLabel = (num && letter) ? `${num}${letter}` : '';
  } else {
    user.subject = document.getElementById('regSubject').value.trim();
  }

  USERS.push(user);
  loginUser(user);
}

function loginUser(user) {
  CURRENT_USER = user;
  DATA.me = { id: user.id, name: user.name, initials: user.initials, color: user.color };

  document.getElementById('sidebarAvatar').textContent      = user.initials;
  document.getElementById('sidebarAvatar').style.background = user.color;
  document.getElementById('sidebarName').textContent        = user.name;
  document.getElementById('sidebarRole').textContent        = user.role === 'teacher'
    ? (user.subject   ? `${user.subject} · преподаватель` : 'Преподаватель')
    : (user.classLabel ? `${user.classLabel} · ученик`    : 'Ученик');

  document.getElementById('composerAvatar').textContent      = user.initials;
  document.getElementById('composerAvatar').style.background = user.color;

  const screen = document.getElementById('authScreen');
  screen.classList.add('hiding');
  setTimeout(() => screen.style.display = 'none', 400);
  showToast(`Добро пожаловать, ${user.name.split(' ')[0]}! 👋`, 'success');
}

function doLogout() {
  CURRENT_USER = null;
  const screen = document.getElementById('authScreen');
  screen.style.display = 'flex';
  requestAnimationFrame(() => screen.classList.remove('hiding'));
}

/* ============================================================
   INIT
   ============================================================ */
function init() {
  renderFeed();
  renderEvents();
  renderGroups();
  renderMessages();

  // Навигация
  document.querySelectorAll('.nav-item, .tab').forEach(el =>
    el.addEventListener('click', () => navigate(el.dataset.tab)));

  // Сообщения
  document.getElementById('sendBtn').addEventListener('click', sendMessage);
  document.getElementById('chatInput').addEventListener('keydown', e => {
    if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); sendMessage(); }
  });

  // Модалки — закрыть по клику на фон и по Escape
  document.querySelectorAll('.modal-overlay').forEach(overlay =>
    overlay.addEventListener('click', e => {
      if (e.target === overlay) overlay.classList.remove('open');
    }));
  document.addEventListener('keydown', e => {
    if (e.key === 'Escape')
      document.querySelectorAll('.modal-overlay.open').forEach(m => m.classList.remove('open'));
  });
}

// Точка входа — грузим данные из JSON, потом всё инициализируем
loadData();
